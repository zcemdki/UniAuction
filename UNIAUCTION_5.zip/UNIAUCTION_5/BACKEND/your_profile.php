<?php
session_start();
include_once "config.php";

if ($link === false) {
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

$account_id = $_POST['account_id'];

$sqlget = "SELECT * FROM user_list WHERE account_id = '" . $account_id . "'";
$sqldata = mysqli_query($link, $sqlget) or die("Error: " . mysqli_error($link));


$row = mysqli_fetch_array($sqldata);
$temp = array();
$temp['account_id'] = $row['account_id'];
$temp['first_name'] = $row['first_name'];
$temp['last_name'] = $row['last_name'];
$temp['email'] = $row['email'];


function item_panels()
{
    global $account_id, $link;
    require_once "config.php";
    $sqlget2 = "SELECT * FROM item_information WHERE account_id = '" . $account_id . "'";
    $sqldata2 = mysqli_query($link, $sqlget2) or die("Error: " . mysqli_error($link));
    $count = 0;
    $j = 0;

    while ($row = mysqli_fetch_array($sqldata2)) {
        if ($count == 3) {
            echo "</div>";
            $count = 0;
        }

        if ($count == 0) {
            echo "<div class='row CW-item-row'>";
            echo "<div class='col-lg-1'>";
            echo "</div>";
        }

        echo "<div class=\"col-lg-3 panel panel-default CW-item-panel\">";
        echo    "<div class=\"col-lg-5 panel-body\">";
        // echo    "<img src=\"...\" class=\"card-img-top\" alt=\"...\">";
        echo      "<img src='" . $row['image'] . "' style='width:100%; min-height:50px; vertical-align:middle'>";
        echo    "</div>";
        echo    "<div class=\"col-lg-7 panel-body\">";
        echo        "<p Class=\"CW-my-items\" name='item_". ($j + 1) ."'>Item #: " . ($j + 1) . " " . $row['item_id'] . "</p>";
        echo        "<p Class=\"CW-my-items\">" . $row['item_name'] . "</p>";
        echo        "<p Class=\"CW-my-items\">" . $row['category'] . "</p>";
        echo        "<p Class=\"CW-my-items\">" . $row['price'] . "</p>";
        echo        "<p Class=\"CW-my-items\">" . $row['color'] . "</p>";
        echo        "<p Class=\"CW-my-items\">" . $row['description'] . "</p>";
        echo        "<p Class=\"CW-my-items\">" . $row['item_condition'] . "</p>";
        echo    "</div>";
        echo "</div>";

        if ($count < 3) {
            $count++;
        }

        $j++;

    }

    echo "</div>";

    mysqli_close($link);

}
?>