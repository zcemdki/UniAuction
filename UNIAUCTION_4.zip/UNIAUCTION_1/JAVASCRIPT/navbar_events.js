document.querySelector("#account_unregistered").addEventListener("click", function () {
    alert("Sorry, you must be signed in to view account details. \nYou will be redirected to the sign in page.");
});

document.querySelector("#cart_unregistered").addEventListener("click", function () {
    alert("Sorry, you must be signed in to view cart. \nYou will be redirected to the sign in page.");
});

document.querySelector("#sell_unregistered").addEventListener("click", function () {
    alert("Sorry, you must be signed in to sell an item. \nYou will be redirected to the sign in page.");
    location.href = "login.php";
});

document.querySelector("#sell_unregistered").addEventListener("click", function () {
    alert("Sorry, you must be signed in to sell an item. \nYou will be redirected to the sign in page.");
    location.href = "login.php";
});
    function emptySearch()
    {
        document.querySelector("#search_item").submit();
    }
