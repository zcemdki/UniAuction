CREATE USER 'CWuser'@'localhost' IDENTIFIED BY 'basics';
GRANT ALL PRIVILEGES ON uniauction.* TO 'CWuser'@'localhost';