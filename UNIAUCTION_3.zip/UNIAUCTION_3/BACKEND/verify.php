<?php

session_start();
require_once "config.php";
$verificationCode = "";
$verificationCode_err = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Check if username is empty
    if (empty(trim($_POST["verify"]))) {
        $verificationCode_err = "Please enter a code.";
    } else {
        $verificationCode = trim($_POST["verify"]);
    }

    // Validate credentials
    if (empty($verificationCode_err)) {
        if ($verificationCode == $_SESSION['verificationCode']) {
            $sql = "UPDATE user_list SET verified = '1'";
            $sqlverify = mysqli_query($link, $sql) or die("Error: " . mysqli_error($link));
            $_SESSION['verified'] = 1;
            header("location:welcome.php");
            exit;
        } else {
            $verificationCode_err = "Wrong verification code";
        }

    }

}
?>