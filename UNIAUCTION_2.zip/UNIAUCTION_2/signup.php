<!doctype html>
<html lang="en">
<head>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Uni Auctions">
    <meta name="generator" content="Jekyll v3.8.5">
    <link href="CSS/bootstrap.min.css" rel="stylesheet">
    <link href="CSS/signup_styles.css" rel="stylesheet">
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
</head>

<body>
<div class="container-fluid">
    <div class="container">
        <div class="login-signup nav-tab-holder">
            <div class="row">
                <div class="col-sm-6">
                    <ul class="nav nav-tabs" role="tablist">
                        <li class="active col-sm-12 blue"><a href="#home">Account</a></li>
                    </ul>
                </div>
            </div>

            <div class="tab-content">
                <div role="tabpanel" class="tab-pane active" id="home">
                    <div class="row">

                        <div class="col-sm-6 mobile-pull">
                            <article role="login">
                                <h3 class="text-center"><i class="fa fa-lock"></i> Account Signup</h3>
                                <form class="signup" action="index.html" method="post">
                                    <div class="form-group">
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="First Name"
                                                   name="first">
                                        </div>
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="Last Name" name="last">
                                        </div>
                                        <input type="text" class="form-control" placeholder="Username">
                                    </div>
                                    <div class="form-group">
                                        <input type="email" class="form-control" placeholder="Email Address">
                                    </div>
                                    <div class="form-group">
                                        <input type="text" class="form-control" placeholder="University">
                                    </div>
                                    <div class="form-group">
                                        <input type="password" class="form-control" placeholder="Password">
                                    </div>
                                    <div class="form-group">
                                        <input type="password" class="form-control" placeholder="Confirm Password">
                                    </div>
                                    <div class="form-group">
                                        <div class="checkbox">
                                            <label>
                                                <input type="checkbox"> Accept terms and conditions.
                                            </label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <input type="submit" class="btn btn-light btn-block" value="Sign Up">
                                    </div>
                                </form>

                            </article>
                        </div>

                        <div class="col-sm-6">
                            <article role="manufacturer" class="text-center">
                                <header class="blue">
                                    Create Account
                                </header>
                                <h1> Account Benefits</h1>
                                <ul class="text-left">
                                    <li><span class="fa fa-check"></span> Free Delivery to Locker</li>
                                    <li><span class="fa fa-check"></span> View Listings</li>
                                    <li><span class="fa fa-check"></span> Priority Locker Availability</li>
                                    <li><span class="fa fa-check"></span> Safe Transactions</li>
                                    <li><span class="fa fa-check"></span> Reliable and Trustworthy Sellers</li>
                                    <li><span class="fa fa-check"></span> Affordable</li>
                                </ul>
                                <a href="#" class="btn btn-light">Signup</a>
                            </article>
                        </div>

                    </div>
                    <!-- end of row -->
                </div>
                <!-- end of home -->

            </div>
        </div>
    </div>
</div>
</body>
</html>



