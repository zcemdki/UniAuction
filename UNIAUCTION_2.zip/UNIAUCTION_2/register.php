<?php
// Include config file
require_once "config.php";

// Define variables and initialize with empty values
$first_name = $last_name = $email = $password = $confirm_password = "";
$first_name_err = $last_name_err = $email_err = $password_err = $confirm_password_err = "";

function generateRandomString($length = 5)
{
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

// Processing form data when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if (empty(trim($_POST["fname"]))) {
        $first_name_err = "Please enter a first name.";
    } else {
        $first_name = trim($_POST["fname"]);
    }

    if (empty(trim($_POST["lname"]))) {
        $last_name_err = "Please enter a first name.";
    } else {
        $last_name = trim($_POST["lname"]);
    }

    // Validate email
    if (empty(trim($_POST["email"]))) {
        $email_err = "Please enter a email.";
    } else {
        // Prepare a select statement
        $sql = "SELECT account_id FROM user_list WHERE email = ?";

        if ($stmt = mysqli_prepare($link, $sql)) {
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $param_email);

            // Set parameters
            $param_email = trim($_POST["email"]);

            // Attempt to execute the prepared statement
            if (mysqli_stmt_execute($stmt)) {
                /* store result */
                mysqli_stmt_store_result($stmt);

                if (mysqli_stmt_num_rows($stmt) == 1) {
                    $email_err = "This email is already taken.";
                } else {
                    $email = trim($_POST["email"]);
                }
            } else {
                echo "Oops! Something went wrong. Please try again later.";
            }
        }

        // Close statement
        mysqli_stmt_close($stmt);
    }

    // Validate password
    if (empty(trim($_POST["password"]))) {
        $password_err = "Please enter a password.";
    } elseif (strlen(trim($_POST["password"])) < 6) {
        $password_err = "Password must have at least 6 characters.";
    } else {
        $password = trim($_POST["password"]);
    }

    // Validate confirm password
    if (empty(trim($_POST["confirm_password"]))) {
        $confirm_password_err = "Please confirm password.";
    } else {
        $confirm_password = trim($_POST["confirm_password"]);
        if (empty($password_err) && ($password != $confirm_password)) {
            $confirm_password_err = "Password did not match.";
        }
    }

    // Check input errors before inserting in database
    if (empty($first_name_err) && empty($last_name_err) && empty($email_err) && empty($password_err) && empty($confirm_password_err)) {
        $verified = 0;
        $verificationCode = generateRandomString();
        // Prepare an insert statement
        $sql = "INSERT INTO user_list (first_name, last_name, email, password, verified, verificationCode) VALUES (?, ?, ?, ?, ?, ?)";

        if ($stmt = mysqli_prepare($link, $sql)) {
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "ssssis", $param_first_name, $param_last_name, $param_email, $param_password, $param_verified, $param_verificationCode);

            // Set parameters
            $param_first_name = $first_name;
            $param_last_name = $last_name;
            $param_email = $email;
            $param_password = password_hash($password, PASSWORD_DEFAULT); // Creates a password hash
            $param_verified = $verified;
            $param_verificationCode = $verificationCode;

            // Attempt to execute the prepared statement
            if (mysqli_stmt_execute($stmt)) {
                // Redirect to login page
                header("location: login.php");
            } else {
                echo "Something went wrong. Please try again later.";
            }
        }

        // Close statement
        mysqli_stmt_close($stmt);
    }
    include_once('mailer.php');
    // Close connection
    mysqli_close($link);
}
?>
<!doctype html>
<html lang="en">
<head>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <!------ Include the above in your HEAD tag ---------->


    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Uni Auctions">
    <meta name="generator" content="Jekyll v3.8.5">
    <title>DVD Rentals</title>
    <link rel="icon" href="img/Untitled.ico">

    <script type="text/javascript" src="js/Javascript.js" defer></script>
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">


    <link href="CSS/register.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <!--<link href="carousel.css" rel="stylesheet">-->

    <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <!------ Include the above in your HEAD tag ---------->
</head>

<body>
<div class="container-fluid">


    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">


    <div class="container">
        <div class="login-signup nav-tab-holder">
            <div class="row">
                <div class="col-sm-6">
                    <ul class="nav nav-tabs" role="tablist">
                        <li class="active col-sm-12 blue"><a href="#home">Account</a></li>
                    </ul>
                </div>
            </div>

            <div class="tab-content">
                <div role="tabpanel" class="tab-pane active" id="home">
                    <div class="row">

                        <div class="col-sm-6 mobile-pull">
                            <article role="login">
                                <h3 class="text-center"><i class="fa fa-lock"></i> Account Signup</h3>
                                <form class="signup" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>"
                                      method="post">
                                    <div class="form-group <?php echo (!empty($first_name_err)) ? 'has-error' : ''; ?>">
                                        <div class="form-group">
                                            <input type="text" name="fname" class="form-control"
                                                   placeholder="First Name" value="<?php echo $first_name; ?>">
                                            <span class="help-block"><?php echo $first_name_err; ?></span>
                                        </div>
                                        <div class="form-group <?php echo (!empty($last_name_err)) ? 'has-error' : ''; ?>">
                                            <input type="text" name="lname" class="form-control" placeholder="Last Name"
                                                   value="<?php echo $last_name; ?>">
                                            <span class="help-block"><?php echo $last_name_err; ?></span>
                                        </div>

                                        <div class="form-group <?php echo (!empty($email_err)) ? 'has-error' : ''; ?>">
                                            <input type="email" name="email" class="form-control"
                                                   placeholder="Email Address" value="<?php echo $email; ?>">
                                            <span class="help-block"><?php echo $email_err; ?></span>
                                        </div>
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="Phone Number">
                                        </div>
                                        <div class="form-group <?php echo (!empty($password_err)) ? 'has-error' : ''; ?>">
                                            <input type="password" name="password" class="form-control"
                                                   placeholder="Password" value="<?php echo $password; ?>">
                                            <span class="help-block"><?php echo $password_err; ?></span>
                                        </div>
                                        <div class="form-group <?php echo (!empty($confirm_password_err)) ? 'has-error' : ''; ?>">
                                            <input type="password" name="confirm_password" class="form-control"
                                                   placeholder="Confirm Password"
                                                   value="<?php echo $confirm_password; ?>">
                                            <span class="help-block"><?php echo $confirm_password_err; ?></span>
                                        </div>
                                        <div class="form-group">
                                            <div class="checkbox">
                                                <label>
                                                    <input type="checkbox"> Please accept the terms and conditions to
                                                    proceed with your request.
                                                </label>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <input type="submit" class="btn btn-light btn-block" value="SUBMIT">
                                        </div>
                                </form>

                                <footer role="signup" class="text-center">
                                    <ul>
                                        <li>
                                            <a href="#">Terms of Use</a>
                                        </li>
                                        <li>
                                            <a href="#">Privacy Statement</a>
                                        </li>
                                    </ul>
                                </footer>

                            </article>
                        </div>

                        <div class="col-sm-6">
                            <article role="manufacturer" class="text-center">
                                <header class="blue">
                                    Create Account
                                </header>
                                <h1> Account Benefits</h1>
                                <ul class="text-left">
                                    <li><span class="fa fa-check"></span> Free Delivery to Locker</li>
                                    <li><span class="fa fa-check"></span> View Listings</li>
                                    <li><span class="fa fa-check"></span> Priority Locker Availability</li>
                                    <li><span class="fa fa-check"></span> Safe Transactions</li>
                                    <li><span class="fa fa-check"></span> Reliable and Trustworthy Sellers</li>
                                    <li><span class="fa fa-check"></span> Affordable</li>
                                </ul>
                                <a href="#" class="btn btn-light">Signup</a>
                            </article>
                        </div>

                    </div>
                    <!-- end of row -->
                </div>
                <!-- end of home -->

            </div>
        </div>
    </div>
</div>
</body>
</html>



