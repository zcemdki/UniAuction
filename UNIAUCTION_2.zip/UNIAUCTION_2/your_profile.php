<?php
session_start();
include_once "config.php";

if ($link === false) {
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

$account_id = $_POST['account_id'];

$sqlget = "SELECT * FROM user_list WHERE account_id = '" . $account_id . "'";
$sqldata = mysqli_query($link, $sqlget) or die("Error: " . mysqli_error($link));


$row = mysqli_fetch_array($sqldata);
    $temp = array();
    $temp['account_id'] = $row['account_id'];
    $temp['first_name'] = $row['first_name'];
    $temp['last_name'] = $row['last_name'];
    $temp['email'] = $row['email'];


function item_panels()
{
    global $account_id, $link;
    require_once "config.php";
    $sqlget2 = "SELECT * FROM item_information WHERE account_id = '" . $account_id . "'";
    $sqldata2 = mysqli_query($link, $sqlget2) or die("Error: " . mysqli_error($link));
    $count = 0;
    $j = 0;

    while ($row = mysqli_fetch_array($sqldata2)) {
        if ($count == 3) {
            echo "</div>";
            $count = 0;
        }

        if ($count == 0) {
            echo "<div class='row CW-item-row'>";
            echo "<div class='col-lg-1'>";
            echo "</div>";
        }

        echo "<div class=\"col-lg-3 panel panel-default CW-item-panel\">";
        echo    "<div class=\"col-lg-5 panel-body\">";
        // echo    "<img src=\"...\" class=\"card-img-top\" alt=\"...\">";
        echo      "<img src='" . $row['image'] . "' style='width:100%; min-height:50px; vertical-align:middle'>";
        echo    "</div>";
        echo    "<div class=\"col-lg-7 panel-body\">";
        echo        "<p Class=\"CW-my-items\" name='item_". ($j + 1) ."'>Item #: " . ($j + 1) . " " . $row['item_id'] . "</p>";
        echo        "<p Class=\"CW-my-items\">" . $row['item_name'] . "</p>";
        echo        "<p Class=\"CW-my-items\">" . $row['category'] . "</p>";
        echo        "<p Class=\"CW-my-items\">" . $row['price'] . "</p>";
        echo        "<p Class=\"CW-my-items\">" . $row['color'] . "</p>";
        echo        "<p Class=\"CW-my-items\">" . $row['description'] . "</p>";
        echo        "<p Class=\"CW-my-items\">" . $row['item_condition'] . "</p>";
        echo    "</div>";
        echo "</div>";

        if ($count < 3) {
            $count++;
        }

        $j++;

    }

    echo "</div>";

    mysqli_close($link);

}
?>
<!DOCTYPE html>
<html lang="en">


<head>
    <meta charset="UTF-8">
    <title>My Account</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
    <link rel="stylesheet" href="CSS/navbar_styles.css">

    <style>
        .CW-item-panel {
            margin: 2rem;
        }

        .CW-item-row {
            align-content: center;
        }

        .carousel-inner img {
            width: 100%; /* Set width to 100% */
            margin: auto;
        }

    .container {
            padding: 80px 120px;
            background: #2d2d30;
            color: #bdbdbd;
        h3 {color: #fff;}
        }

    </style>
</head>
<body>
<?php include_once ('navbar_loggedin.php')?>

<div class="container-fluid">
    <div class="col-lg-1">

    </div>
    <div class="row">
        <div class="col-lg-4 panel panel-default">
            <div class="col-lg-5 panel-body">
                <div class="row">
                    <img src="..." class="card-img-top" alt="...">
                </div>

                <div class="row">
                    Report profile
                </div>

            </div>

            <div class="col-lg-7 panel-body">
                <p class="CW-profile-header"><b><?php echo $temp['first_name'] . $temp["last_name"]; ?></p>
                <P Class="CW-profile-content">University: <?php ?></P>
                <P Class="CW-profile-content">Total Sales: 11 </P>
                <p Class="CW-profile-content"><b>Details</b></p>
                <p Class="CW-profile-content">lola ipsum mori duka lola oepwm ioermp</p>
                <p Class="CW-profile-content"><b>Recent listings</b></p>
                <p Class="CW-profile-content">lola ipsum mori duka lola oepwm ioermp</p>
                <p class="CW-flush-right">CHAT</p>
            </div>
        </div>
    </div>

</div>
<div class="container-fluid">
    <?php
    item_panels();
    ?>
</div>

</body>
<?php include_once 'footer.php';?>

<!-- JS for dropdowns-->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

</html>