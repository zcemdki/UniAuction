<?php
// Initialize the session
session_start();

if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: login.php");
    exit;
}

// Include config file
require_once "config.php";

// Define variables and initialize with empty values
$item_name = $category = $price = $color = $description = $item_condition = "";
$item_name_err = $category_err = $price_err = $color_err = $description_err = $item_condition_err = "";

// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){

    if(empty(trim($_POST["item_name"]))){
        $item_name_err = "Please enter a item name.";
    } else{
        $item_name = trim($_POST["item_name"]);
    }

    if(empty(trim($_POST["category"]))){
        $category_err = "Please enter a category.";
    } else{
        $category = trim($_POST["category"]);
    }

    if(empty(trim($_POST["price"]))){
        $price_err = "Please enter a price.";
    } else{
        $price = trim($_POST["price"]);
    }

    // Validate password
    if(empty(trim($_POST["color"]))){
        $color_err = "Please enter a color.";
    } else{
        $color = trim($_POST["color"]);
    }

    // Validate confirm password
    if(empty(trim($_POST["description"]))){
        $description_err = "Please write a description of the item.";
    } else{
        $description = trim($_POST["description"]);
    }

    // Validate confirm password
    if(empty(trim($_POST["item_condition"]))){
        $item_condition_err = "Please indicate condition of item.";
    } else{
        $item_condition = trim($_POST["item_condition"]);
    }


    // Check input errors before inserting in database
    if(empty($item_name_err) && empty($category_err) && empty($price_err) && empty($color_err) && empty($description_err) && empty($item_condition_err)){

        // Prepare an insert statement
        $sql = "INSERT INTO item_information (account_id, item_name, category, price, color, description, item_condition) VALUES (?, ?, ?, ?, ?, ?, ?)";

        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "ississs", $param_account_id,  $param_item_name, $param_category, $param_price, $param_color, $param_description, $param_item_condition);

            // Set parameters
            $param_account_id = $_SESSION['account_id'];
            $param_item_name = $item_name;
            $param_category = $category;
            $param_price = $price;
            $param_color = $color;
            $param_description = $description;
            $param_item_condition = $item_condition;


            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                header("location: my_account.php");
                exit;
            } else{
                echo "Something went wrong. Please try again later.";
            }
        }

        // Close statement
        mysqli_stmt_close($stmt);
    }

    // Close connection
    mysqli_close($link);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sell an item</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <link rel="stylesheet" href="CSS/navbar_styles.css">
    <!-- JS for dropdowns-->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js" defer></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous" defer></script>

    <style type="text/css">
        body{ font: 14px sans-serif; }
        .wrapper{ padding: 20px; }
    </style>
</head>
<body>
<?php include_once ('navbar_loggedin.php')?>
<div class="wrapper panel panel-default col-sm-offset-4 col-sm-4">
    <h2>Sell an item</h2>
    <p>Please complete all fields.</p>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <div class="form-group <?php echo (!empty($item_name_err)) ? 'has-error' : ''; ?>">
            <label>Item Name</label>
            <input type="text" name="item_name" class="form-control" value="<?php echo $item_name; ?>">
            <span class="help-block"><?php echo $item_name_err; ?></span>
        </div>
        <div class="form-group <?php echo (!empty($category_err)) ? 'has-error' : ''; ?>">
            <label>Pick a Category</label>
            <select name="category" class="form-control">
                <option value="" selected="selected">Select a Category</option>
                <option value="Electronics & Computers">Electronics & Computers</option>
                <option value="Clothes, Shoes & Watches">Clothes, Shoes & Watches</option>
                <option value="Food & Grocery">Food & Grocery</option>
                <option value="Health & Beauty">Health & Beauty</option>
                <option value="Home & Kitchenware">Home & Kitchenware</option>
            </select>
            <span class="help-block"><?php echo $category_err; ?></span>
        </div>
        <div class="form-group <?php echo (!empty($price_err)) ? 'has-error' : ''; ?>">
            <label>Price (£)</label>
            <input type="number" name="price" class="form-control" value="<?php echo $price; ?>">
            <span class="help-block"><?php echo $price_err; ?></span>
        </div>
        <div class="form-group <?php echo (!empty($color_err)) ? 'has-error' : ''; ?>">
            <label>Color</label>
            <input type="color" name="color" class="form-control" value="<?php echo $color; ?>">
            <span class="help-block"><?php echo $color_err; ?></span>
        </div>
        <div class="form-group <?php echo (!empty($description_err)) ? 'has-error' : ''; ?>">
            <label>Description</label>
            <input type="text" name="description" class="form-control" value="<?php echo $description; ?>">
            <span class="help-block"><?php echo $description_err; ?></span>
        </div>
        <div class="form-group <?php echo (!empty($item_condition_err)) ? 'has-error' : ''; ?>">
            <label>Condition</label>
            <select name="item_condition" class="form-control">
                <option value="" selected="selected">Choose a Condition</option>
                <option value="New">New</option>
                <option value="Like New">Like New</option>
                <option value="Very Good">Very Good</option>
                <option value="Good">Good</option>
                <option value="Acceptable">Acceptable</option>
            </select>
            <span class="help-block"><?php echo $item_condition_err; ?></span>
        </div>
        <div class="row">
            <div class="form-group col-sm-9">
                <input type="submit" class="btn btn-primary" value="Add Item">
            </div>
            <div class="col-sm-3">
                <input type="reset" class="btn btn-danger" value="Reset">
            </div>
        </div>
        <div class="col-sm-offset-8 col-sm-4">
            <a class="btn btn-warning" href="my_account.php">Cancel Add Item</a>
        </div>
        <br>
    </form>
</div>
</body>

<?//php include_once 'footer.php';?>
<!-- JS for dropdowns-->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js" ></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous" ></script>

</html>