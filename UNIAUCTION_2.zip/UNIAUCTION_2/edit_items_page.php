<?php
// Initialize the session
session_start();

if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: login.php");
    exit;
}
require_once "config.php";
$sqlget = "SELECT * FROM item_information WHERE account_id = '" . $_SESSION['account_id'] . "'";
$sqldata = mysqli_query($link, $sqlget) or die("Error: " . mysqli_error($link));
$item_id = array();
$item_name = array();
$category = array();
$price = array();
$color = array();
$description = array();
$item_condition = array();
$i = 1;

function get_options () {
    global $sqldata;
    global $i, $item_id, $item_name, $category, $price, $color, $description, $item_condition;
    while ($row = mysqli_fetch_array($sqldata)) {

        $item_id[$i] = $row['item_id'];
        $item_name[$i] = $row['item_name'];
        $category[$i] = $row['category'];
        $price[$i] = $row['price'];
        $color[$i] = $row['color'];
        $description[$i] = $row['description'];
        $item_condition[$i] = $row['item_condition'];
        $i++;
    }

    foreach($item_name as $value){
        echo "<option value='" . $value . "'>" . $value . "</option>";
    }

}

$item_id_input = $item_name_input = $category_input = $price_input = $color_input = $description_input = $item_condition_input = "";
$item_name_err = $category_err = $price_err = $color_err = $description_err = $item_condition_err = "";

// Processing form data when form is submitted
if(isset($_POST["enter"])){

    $item_id_input = trim($_POST['item_id']);

    if(empty(trim($_POST["item_name"]))){
        $item_name_err = "Please enter a item name.";
    } else{
        $item_name_input = trim($_POST["item_name"]);
    }

    if(empty(trim($_POST["category"]))){
        $category_err = "Please enter a category.";
    } else{
        $category_input = trim($_POST["category"]);
    }

    if(empty(trim($_POST["price"]))){
        $price_err = "Please enter a price.";
    } else{
        $price_input = trim($_POST["price"]);
    }

    // Validate password
    if(empty(trim($_POST["color"]))){
        $color_err = "Please enter a color.";
    } else{
        $color_input = trim($_POST["color"]);
    }

    // Validate confirm password
    if(empty(trim($_POST["description"]))){
        $description_err = "Please write a description of the item.";
    } else{
        $description_input = trim($_POST["description"]);
    }

    // Validate confirm password
    if(empty(trim($_POST["item_condition"]))){
        $item_condition_err = "Please indicate condition of item.";
    } else{
        $item_condition_input = trim($_POST["item_condition"]);
    }


    // Check input errors before inserting in database
    if(empty($item_name_err) && empty($category_err) && empty($price_err) && empty($color_err) && empty($description_err) && empty($item_condition_err)){

        // Prepare an insert statement
        $sql = "UPDATE item_information SET item_name=?, category=?, price=?, color=?, description=?, item_condition=? WHERE item_id=?";

        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "ssisssi",$param_item_name, $param_category, $param_price, $param_color, $param_description, $param_item_condition, $param_item_id);

            // Set parameters
            $param_item_id = $item_id_input;
            $param_item_name = $item_name_input;
            $param_category = $category_input;
            $param_price = $price_input;
            $param_color = $color_input;
            $param_description = $description_input;
            $param_item_condition = $item_condition_input;


            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                header("location: my_account.php");
            } else{
                echo "Something went wrong. Please try again later.";
            }
        }

        // Close statement
        mysqli_stmt_close($stmt);
    }

    // Close connection
    mysqli_close($link);
}

// Processing form data when form is submitted
if(isset($_POST["delete_item"])){

    $item_id_input = trim($_POST['item_id']);

        // Prepare an insert statement

        $sql = "DELETE FROM item_information WHERE item_id=?";
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "i",$param_item_id);

            // Set parameters
            $param_item_id = $item_id_input;

            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                header("location: my_account.php");
            } else{
                echo "Something went wrong. Please try again later.";
            }
        }

        // Close statement
        mysqli_stmt_close($stmt);

    // Close connection
    mysqli_close($link);
}


?>
<!DOCTYPE html>
<html lang="en">


<head>
    <meta charset="UTF-8">
    <title>Edit Item</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
    <link rel="stylesheet" href="CSS/navbar_styles.css">
    <style type="text/css">
        body{ font: 14px sans-serif; }
        .wrapper{padding: 20px; }
    </style>

</head>



<body>
<?php include_once ('navbar_loggedin.php')?>
<div class="wrapper panel panel-default col-sm-4 col-sm-offset-4" >
    <h2>Item information</h2>
    <p>Choose the item you want to edit.</p>

    <form class="form-group" id="items" name="items" method="post" action="">
        <select class=form-control id='item' name="item" >

            <?php get_options() ?>

        </select>
        <br>
        <input class="btn btn-primary col-sm-offset-9 col-sm-3" type="submit" name="submit" value="Go">
    </form>

    <?php

    global $j;
    if (isset($_POST['submit'])) {
        $selectOption = $_POST['item'];
        ?>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <?php

        for ($j = 1; $j <= mysqli_num_rows($sqldata); $j++) {
            if ($selectOption == $item_name[$j]) {
                ?>
                <div class="form-group">
                    <br> <br> <br>
                    <label>Item ID</label>
                    <input type="text" name="item_id" class="form-control" value="<?php echo $item_id[$j]; ?>">
                </div>
                <div class="form-group">
                <label>Item Name</label>
                <input type="text" name="item_name" class="form-control" value="<?php echo $item_name[$j]; ?>">
                </div>
                <div class="form-group">
                    <label>Item category</label>
                    <select name="category" class="form-control">
                        <option value="" selected="selected">Select a Category</option>
                        <option value="Electronics & Computers">Electronics & Computers</option>
                        <option value="Clothes, Shoes & Watches">Clothes, Shoes & Watches</option>
                        <option value="Food & Grocery">Food & Grocery</option>
                        <option value="Health & Beauty">Health & Beauty</option>
                        <option value="Home & Kitchenware">Home & Kitchenware</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Item price</label>
                    <input type="text" name="price" class="form-control" value="<?php echo $price[$j]; ?>">
                </div>
                <div class="form-group">
                    <label>Item color</label>
                    <input type="text" name="color" class="form-control" value="<?php echo $color[$j]; ?>">
                </div>
                <div class="form-group">
                    <label>Item description</label>
                    <input type="text" name="description" class="form-control" value="<?php echo $description[$j]; ?>">
                </div>
                <div class="form-group">
                    <label>Item condition</label>
                    <select name="item_condition" class="form-control">
                        <option value="" selected="selected">Choose a Condition</option>
                        <option value="New">New</option>
                        <option value="Like New">Like New</option>
                        <option value="Very Good">Very Good</option>
                        <option value="Good">Good</option>
                        <option value="Acceptable">Acceptable</option>
                    </select>
                </div>
                <div class="row">
                <div class="form-group col-sm-9">
                    <input type="submit" name="enter" class="btn btn-primary" value="Confirm Edit">
                </div>
                    <div class="col-sm-3">
                        <input type="submit" name="delete_item" class="btn btn-danger" value="Delete Item"
                    </div>
                </div>
                <a class="col-sm-offset-9 col-sm-3 btn btn-warning " href="my_account.php">Cancel Edit</a>

                <?php

            }
        }
    }

    ?>
        </form>
</div>

</body>
<?//php include_once 'footer.php';?>

<!-- JS for dropdowns-->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
